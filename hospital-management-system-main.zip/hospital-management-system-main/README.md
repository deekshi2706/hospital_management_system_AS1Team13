# app-java-project

## Hospital Management System

##### to connect to sql, in src/conn.java change the port,username and password then run the queries in the .sql file
